export const environment = {
  production: true,
  api: {
    auth: 'https://YOUR_PROD_AUTH',
    customer: 'https://YOUR_PROD_CUSTOMER',
    account: 'https://YOUR_PROD_ACCOUNT',
    transaction: 'https://YOUR_PROD_TX',
    notification: 'https://YOUR_PROD_NOTIFY',
  }
};
