export const environment = {
  production: false,
  api: {
    auth: 'http://localhost:8080',
    customer: 'http://localhost:8081',
    account: 'http://localhost:8082',
    transaction: 'http://localhost:8083',
    notification: 'http://localhost:8085',
  }
};
