import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonItem, IonLabel, IonInput, IonButton, IonList, IonText } from '@ionic/angular/standalone';
import { AuthService } from '../../core/services/auth.service';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [ReactiveFormsModule, IonContent, IonHeader, IonTitle, IonToolbar, IonItem, IonLabel, IonInput, IonButton, IonList, IonText],
  template: `
<ion-header><ion-toolbar><ion-title>Register</ion-title></ion-toolbar></ion-header>
<ion-content class="ion-padding">
  <form [formGroup]="form" (ngSubmit)="onSubmit()">
    <ion-list>
      <ion-item>
        <ion-label position="stacked">Email</ion-label>
        <ion-input type="email" formControlName="email"></ion-input>
      </ion-item>
      <ion-item>
        <ion-label position="stacked">Password</ion-label>
        <ion-input type="password" formControlName="password"></ion-input>
      </ion-item>
    </ion-list>
    <ion-button expand="block" type="submit" [disabled]="form.invalid || loading">{{ loading ? 'Creating...' : 'Register' }}</ion-button>
    <ion-text color="success" *ngIf="message">{{ message }}</ion-text>
  </form>
</ion-content>
`})
export class RegisterPage {
  loading = false;
  message = '';
  form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  onSubmit() {
    if (this.form.invalid) return;
    this.loading = true; this.message = '';
    this.auth.register(this.form.value as any).subscribe({
      next: () => {
        this.message = 'Account created. Please login.';
        setTimeout(() => this.router.navigate(['/auth/login']), 800);
      },
      error: () => { this.loading = false; }
    });
  }
}
